#pragma once
#include<iostream>
#include "clsUser.h"
#include "Global.h"
#include"clsDate.h"
using namespace std;
class clsScreen
{
protected:
	static void _DrawScreenHeader(string Title, string SubTitle="") {
        clsDate date;
        cout << "\t\t\t\t\t______________________________________";
        cout << "\n\n\t\t\t\t\t  " << Title;
        if (SubTitle != "")
        {
            cout << "\n\t\t\t\t\t  " << SubTitle;
        }
        cout << "\n\t\t\t\t\t______________________________________\n";
        cout << "\t\t\t\t\t" << "User:";
        cout << CurrentUser.UserName;
        cout << "\n\t\t\t\t\t"<<"Date:";
        date.Print();



	}
    static bool CheckAccessRight(clsUser::enPermissions Permission) {
        if (!CurrentUser.CheckAccessPermitions(Permission))
        {
            cout << "\t\t\t\t\t______________________________________";
            cout << "\n\n\t\t\t\t\t  Access Denied! Contact your Admin.";
            cout << "\n\t\t\t\t\t______________________________________\n\n";
            return false;
        }
        else
        {
            return true;
        }
    }

};

